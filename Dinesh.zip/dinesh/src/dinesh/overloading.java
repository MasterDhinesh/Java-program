package dinesh;


class N {
	void apple(int a,int b) {
		System.out.println(a+b);
	}

	void apple(String m,int n) {
		System.out.println(m+" "+n);
	}
}

public class overloading{
public static void main(String[] args) {
	
	N o=new N();
	o.apple(23, 5);
	
	o.apple("java", 8);
}
}

