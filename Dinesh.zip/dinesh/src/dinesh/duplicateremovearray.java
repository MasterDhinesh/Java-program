package dinesh;

public class duplicateremovearray {

	public static void main(String args[]) {
		int a[] = {2,3,4,2,3,5,6};
		int n = a.length;
		System.out.println("Unique elements:");
		for(int i =0;i<n;i++) {
			int count = 0;
			for(int j=0;j<i;j++) {
				if(a[i]==a[j]){
					count++;
				}
			}
			if(count == 0) {
				System.out.println(a[i]+"");
			}
		}
	}
}
