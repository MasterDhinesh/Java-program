package dinesh;

public class alternate {

	public static void main(String[] args) {
	        String word = "welcome";
	        char[] letters = word.toCharArray();
	        for (int i = 0; i < letters.length; i++) {
	            if (i % 2 == 0) {
	                letters[i] = Character.toUpperCase(letters[i]);
	            } else {
	                letters[i] = Character.toLowerCase(letters[i]);
	            }
	        }
	        System.out.println(new String(letters));
	    }
	}

	

