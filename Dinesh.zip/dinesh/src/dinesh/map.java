package dinesh;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;


public class map {
	
	public static void main(String args[]) {
//	HashMap<Integer,String> s = new HashMap<>();
//	s.put(1,"apple");
//	s.put(2,"banana");
//	s.put(3,"Mango");
//	System.out.println(s.hashCode());
//	
//	System.out.println(s.containsValue(s));
//	System.out.println(s.get(s));
		
//		LinkedHashMap<Integer,String> s = new LinkedHashMap<>();
//		s.put(1,"apple");
//s.put(2,"banana");
//		s.put(3,"Mango");
//		s.put(4,"apple");	
//		System.out.println(s);
//		System.out.println(s.clone());
//		System.out.println(s.containsKey(s));
		
		TreeMap s = new TreeMap();
		s.put(9,"apple");
     s.put(10,"banana");
	s.put(9,"Mango");
		s.put(8,"apple");	
		System.out.println(s);
		System.out.println(s.clone());
		System.out.println(s.firstKey());
		
		
		
	}

}
