package dinesh;

class z{
	void apple(int a,int b) {
		System.out.println(a+b);
	}
}
class y{
	void apple(int d,int e) {
		System.out.println(d+e);
	}
}

public class overriding {
public static void main(String[] args) {
	
	z o=new z();
	o.apple(23, 9);
	y o1=new y();
	o1.apple(3, 5);
}
}
