package dinesh;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class Set {
	public static void main(String args[]) {
//		HashSet<String> s = new HashSet<>();
//		s.add("apple");
//		s.add("banana");
//		s.add("Mango");
//		System.out.println(s.addAll(s));
//		System.out.println(s.isEmpty());
//		System.out.println(s.getClass());	
//		
//		TreeSet s = new TreeSet();
//		s.add(9);
//		s.add(45);
//		s.add(45);
//		System.out.println(s);
//		System.out.println(s.first());
//		
//		System.out.println(s.remove(0));	
		
		LinkedHashSet<Long> s = new LinkedHashSet<>();
		s.add(12345678l);
		s.add(7890l);
		s.add(9000l);
		System.out.println(s.containsAll(s));
		System.out.println(s.toString());
		System.out.println(s.newLinkedHashSet(0));
		
	}

}
