package dinesh;

public class calling {
	
		static class B {
			void apple1() {
				System.out.println("class B");
			}
		}
		public static void main(String[] args) {
	    
	    
	    B obj1=new B();
	    obj1.apple1();
		}
	


}



