package dinesh;

public class removespace {
	
	    public static void main(String[] args) {
	        String text = "hello hi java";
	        char[] letters = text.toCharArray();
	        String result = "";
	        for (char c : letters) {
	            if (c != ' ') {
	                result += c;
	            }
	        }
	        System.out.println(result);
	    }
	}

	