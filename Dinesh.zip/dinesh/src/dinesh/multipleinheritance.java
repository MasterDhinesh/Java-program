package dinesh;


interface L {
	void apple();

}

interface M {
	void apple1();
}

public class multipleinheritance implements L, M{

	public void apple() {
		System.out.println("A");
	}

	public void apple1() {
		System.out.println("B");
	}

	public static void main(String[] args) {
		multipleinheritance dd = new multipleinheritance();
		dd.apple();
		dd.apple1();
	}
}

