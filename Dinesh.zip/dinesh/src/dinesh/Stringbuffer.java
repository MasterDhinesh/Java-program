package dinesh;

public class Stringbuffer {
	public static void main(String args[]) {
		StringBuffer s = new StringBuffer("hi");
		s.append("hello");
		System.out.println(s);
		
		StringBuffer s1 = new StringBuffer("hi");
		s1.insert(0,"hello");
		System.out.println(s1);
		
		StringBuffer s2 = new StringBuffer("hello");
		s2.delete(0,4);
		System.out.println(s2);
		
		StringBuffer s3 = new StringBuffer("hello");
		s3.replace(0,4,"hi");
		System.out.println(s3);
		
		
	}

}
