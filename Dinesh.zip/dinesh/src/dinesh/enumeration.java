package dinesh;

enum Day{
	monday,tuesday,wednesday,thursday,friday,saturday,sunday
}

public class enumeration{
	public static void main(String[] args) {
	for(Day d: Day.values()) {
		System.out.println("day:"+ d);	
	}

	
}
}
