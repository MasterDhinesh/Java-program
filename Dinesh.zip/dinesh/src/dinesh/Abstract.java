package dinesh;


abstract class F {

	abstract void apple();

	void apple1() {
		System.out.println("hii");
	}
}

public class Abstract extends F{

	void apple() {
		System.out.println("abstract");
	}

	public static void main(String[] args) {
		Abstract dd=new Abstract();
		dd.apple();
		dd.apple1();
	}
}

