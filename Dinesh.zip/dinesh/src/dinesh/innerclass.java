package dinesh;

public class innerclass {
	
 class B {
			void apple1() {
				System.out.println("class B");
			}
		}
		public static void main(String[] args) {
	    
	    innerclass o=new innerclass();
	    innerclass.B obj1=o.new B();
	    obj1.apple1();
		}
	
	
}

