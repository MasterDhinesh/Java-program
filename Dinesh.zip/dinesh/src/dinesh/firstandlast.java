package dinesh;

public class firstandlast {
	
	    public static void main(String[] args) {
	        String word = "welcome";
	        char[] letters = word.toCharArray();
	        letters[0] = Character.toUpperCase(letters[0]);
	        letters[letters.length - 1] = Character.toUpperCase(letters[letters.length - 1]);
	        for (int i = 1; i < letters.length - 1; i++) {
	            letters[i] = Character.toLowerCase(letters[i]);
	        }
	        System.out.println(new String(letters));
	    }
	}



