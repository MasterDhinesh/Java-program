package dinesh;

public class wordfirstlastupper {

	    public static void main(String[] args) {
	        String sentence = "Hello HiI JavA";
	        String[] words = sentence.split(" ");
	        String result = "";

	        for (String word : words) {
	            char[] letters = word.toLowerCase().toCharArray();
	            if (letters.length > 1) {
	                letters[0] = Character.toUpperCase(letters[0]);
	                letters[letters.length - 1] = Character.toUpperCase(letters[letters.length - 1]);
	            } else {
	                letters[0] = Character.toUpperCase(letters[0]);
	            }
	            result += new String(letters) + " ";
	        }

	        System.out.println(result.trim());
	    }

	
}



