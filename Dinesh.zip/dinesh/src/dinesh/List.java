package dinesh;


	import java.util.ArrayList;
	import java.util.LinkedList;
	import java.util.Vector;


	public class List {
		public static void main(String args[]) {
//			ArrayList l = new ArrayList<>();
//			l.add(23);
//			l.add(0,56);
//			l.add(25);
//			l.add(56);
//			l.add(2,"java");
//			System.out.println(l.hashCode());
//			System.out.println(l);
//			System.out.println(l.clone());
//			System.out.println(l.contains(l));
//			System.out.println(l.addAll(l));
			
//			LinkedList l = new LinkedList<>();
//			l.add(99);
//			l.add(99);
//			l.add(45);
//			l.add(0);
//			System.out.println(l.indexOf(l));
//			System.out.println(l.peek());
//			System.out.println(l.poll());
//			System.out.println(l.size());
//			System.out.println(l.descendingIterator());
			

			
			Vector<String> l= new Vector<String>();
			l.add("dinesh");
			l.add(0, "hi");
			l.add("SomaSundaram");
			System.out.println(l);
			System.out.println(l.equals(l));
			System.out.println(l.reversed());
			System.out.println(l.listIterator(0));
		
			
			
			
		}

	}



