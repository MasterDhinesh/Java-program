package dinesh;



interface K {

	void apple();

	static void apple1() {
		System.out.println("static");
	}
	default void apple2() {
		System.out.println("default");
	}
}

public class Interface implements K {

	public void apple() {
		System.out.println("abstract");
	}

	public static void main(String[] args) {
		Interface dd=new Interface();
		dd.apple();
		dd.apple2();
		K.apple1();
		
	}
}



