package dinesh;
	public class uppercase {

		public static void main(String[] args) {
			String a = "welcome";
			char b[] = a.toCharArray();// w   e l c o m e
	                                   //b[0]
			for(int i=0;i<=a.length()-1;i++) {
				b[i]= (char)((int)b[i]-32);
				System.out.print(b[i]);
			}
		}
	}
	
