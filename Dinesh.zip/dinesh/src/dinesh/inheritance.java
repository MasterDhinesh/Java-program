package dinesh;

	class A{
		void apple() {
			System.out.println("class A");
		}
	}
	class B extends A{
		void fruits() {
			System.out.println("class B");
		}
	}
	public class inheritance {
		public static void main(String[] args) {
	   B obj=new  B();
	   obj.fruits();
	   obj.apple();
			
		}
	}

	
