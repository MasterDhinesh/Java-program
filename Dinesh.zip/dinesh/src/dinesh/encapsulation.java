package dinesh;

class E{

	
	private int var;

	void getter() {
		System.out.println(var);
	}
	void setter(int x) {
		var=x;
	}
}

public class encapsulation {

	public static void main(String[] args) {
		E obj = new E();
		obj.setter(20);
		obj.getter();
	}
}



