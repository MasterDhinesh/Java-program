package dinesh;

class S{
	void appleA() {
		System.out.println("Class A");
	}
}
class R extends S{
	void appleB() {
		System.out.println("Class B");
	}
}

class U extends R{
	void appleC() {
		System.out.println("Class C");
	}
}
class D extends S{
	void appleD() {
		System.out.println("Class D");
	}
}
public class hybrid {
public static void main(String[] args) {
	
	U obj=new U();
	obj.appleA();
	obj.appleB();
	obj.appleC();
	
	D obj1=new D();
	obj1.appleA();
	obj1.appleD();
	
}
}


