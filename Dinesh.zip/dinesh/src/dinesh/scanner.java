package dinesh;

import java.util.Scanner;

public class scanner {
    public static void main(String[] args) {
        // Create Scanner object
        Scanner input = new Scanner(System.in);

        // Read name
        System.out.print("Enter your name: ");
        String name = input.nextLine();

        // Read age
        System.out.print("Enter your age: ");
        int age = input.nextInt();

        // Display result
        System.out.println("Welcome " + name + "! You are " + age + " years old.");

        // Close the scanner
        input.close();
    }
}
