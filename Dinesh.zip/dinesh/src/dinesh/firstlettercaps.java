package dinesh;

public class firstlettercaps {

	    public static void main(String[] args) {
	        String word = "welcome";
	        char[] letters = word.toCharArray();
	        letters[0] = Character.toUpperCase(letters[0]);
	        for (int i = 1; i < letters.length; i++) {
	            letters[i] = Character.toLowerCase(letters[i]);
	        }
	        System.out.println(new String(letters));
	    }
	}




