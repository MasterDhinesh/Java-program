package com.example.weighbridge.controller;

import com.example.weighbridge.entity.WeighEntry;
import com.example.weighbridge.service.WeighEntrytService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/weighbridge")
public class WeighEntryController {

    @Autowired
    private WeighEntrytService service;

    @PostMapping
    public WeighEntry create(@RequestBody WeighEntry entry) {
        return service.createEntry(entry);
    }

    @GetMapping
    public List<WeighEntry> getAll() {
        return service.getAllEntries();
    }

    @GetMapping("/{id}")
    public WeighEntry getById(@PathVariable Long id) {
        return service.getEntryById(id);
    }

    @PutMapping("/{id}")
    public WeighEntry update(@PathVariable Long id, @RequestBody WeighEntry updated) {
        return service.updateEntry(id, updated);
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) {
        service.deleteEntry(id);
        return "Deleted weigh entry with ID: " + id;
    }
}