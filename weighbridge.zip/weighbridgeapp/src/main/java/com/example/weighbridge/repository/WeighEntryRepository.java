package com.example.weighbridge.repository;

import com.example.weighbridge.entity.WeighEntry;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WeighEntryRepository extends JpaRepository<WeighEntry, Long> {
}