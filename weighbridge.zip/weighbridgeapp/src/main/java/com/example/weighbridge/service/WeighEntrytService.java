package com.example.weighbridge.service;

import com.example.weighbridge.entity.WeighEntry;

import java.util.List;

public interface WeighEntrytService {
    WeighEntry createEntry(WeighEntry entry);
    List<WeighEntry> getAllEntries();
    WeighEntry getEntryById(Long id);
    WeighEntry updateEntry(Long id, WeighEntry updatedEntry);
    void deleteEntry(Long id);
}