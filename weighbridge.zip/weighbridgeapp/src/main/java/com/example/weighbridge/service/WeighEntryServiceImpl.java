package com.example.weighbridge.service;

import com.example.weighbridge.entity.WeighEntry;
import com.example.weighbridge.repository.WeighEntryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WeighEntryServiceImpl implements WeighEntrytService {

    @Autowired
    private WeighEntryRepository repo;

    @Override
    public WeighEntry createEntry(WeighEntry entry) {
        return repo.save(entry);
    }

    @Override
    public List<WeighEntry> getAllEntries() {
        return repo.findAll();
    }

    @Override
    public WeighEntry getEntryById(Long id) {
        return repo.findById(id).orElse(null);
    }

    @Override
    public WeighEntry updateEntry(Long id, WeighEntry updated) {
        return repo.findById(id).map(entry -> {
            entry.setVehicleNumber(updated.getVehicleNumber());
            entry.setGrossWeight(updated.getGrossWeight());
            entry.setTareWeight(updated.getTareWeight());
            entry.setMaterial(updated.getMaterial());
            entry.setEntryDate(updated.getEntryDate());
            return repo.save(entry);
        }).orElse(null);
    }

    @Override
    public void deleteEntry(Long id) {
        repo.deleteById(id);
    }
}
