package com.example.weighbridge.entity;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
public class WeighEntry {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String vehicleNumber;
    private double grossWeight;
    private double tareWeight;
    private String material;
    private LocalDate entryDate;

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getVehicleNumber() { return vehicleNumber; }
    public void setVehicleNumber(String vehicleNumber) { this.vehicleNumber = vehicleNumber; }

    public double getGrossWeight() { return grossWeight; }
    public void setGrossWeight(double grossWeight) { this.grossWeight = grossWeight; }

    public double getTareWeight() { return tareWeight; }
    public void setTareWeight(double tareWeight) { this.tareWeight = tareWeight; }

    public String getMaterial() { return material; }
    public void setMaterial(String material) { this.material = material; }

    public LocalDate getEntryDate() { return entryDate; }
    public void setEntryDate(LocalDate entryDate) { this.entryDate = entryDate; }
}